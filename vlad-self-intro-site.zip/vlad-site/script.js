const root = document.documentElement;
const themeToggle = document.querySelector('#themeToggle');
const typeTarget = document.querySelector('#type');
const year = document.querySelector('#year');
const form = document.querySelector('#helloForm');
const formHint = document.querySelector('#formHint');

const savedTheme = localStorage.getItem('vlad-theme');
if (savedTheme) {
  root.dataset.theme = savedTheme;
  themeToggle.setAttribute('aria-pressed', savedTheme === 'dark');
} else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
  root.dataset.theme = 'dark';
  themeToggle.setAttribute('aria-pressed', 'true');
}

themeToggle.addEventListener('click', () => {
  const nextTheme = root.dataset.theme === 'dark' ? 'light' : 'dark';
  root.dataset.theme = nextTheme;
  localStorage.setItem('vlad-theme', nextTheme);
  themeToggle.setAttribute('aria-pressed', nextTheme === 'dark');
});

year.textContent = new Date().getFullYear();

const lines = [
  'I love music, robots, websites, and coffee.',
  'I play guitar, piano, and other instruments.',
  'I want to learn many programming languages.'
];

let lineIndex = 0;
let charIndex = 0;
let deleting = false;

function typeLoop() {
  const current = lines[lineIndex];
  const visible = current.slice(0, charIndex);
  typeTarget.textContent = visible;

  if (!deleting && charIndex < current.length) {
    charIndex += 1;
    setTimeout(typeLoop, 45);
    return;
  }

  if (!deleting && charIndex === current.length) {
    deleting = true;
    setTimeout(typeLoop, 1500);
    return;
  }

  if (deleting && charIndex > 0) {
    charIndex -= 1;
    setTimeout(typeLoop, 24);
    return;
  }

  deleting = false;
  lineIndex = (lineIndex + 1) % lines.length;
  setTimeout(typeLoop, 350);
}

typeLoop();

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const data = new FormData(form);
  const name = data.get('name').trim();
  const message = data.get('message').trim();

  if (!name || !message) return;

  const text = `Hi Vlad! My name is ${name}. ${message}`;
  navigator.clipboard?.writeText(text).then(() => {
    formHint.textContent = 'Message copied to clipboard!';
  }).catch(() => {
    formHint.textContent = text;
  });

  form.reset();
});
